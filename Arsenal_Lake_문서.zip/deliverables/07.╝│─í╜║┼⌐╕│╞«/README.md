# 개정이력

|    날짜    | 변경내용  | 작성자 | 비고 |
| :--------: | :-------: | :----: | :--: |
| 2019.05.15 | 최조 작성 | 김병준 |      |
|            |           |        |      |

# 설치스크립트 

## [standalone 버전](http://gitlab.msa.kt.com/datalake/datalake/blob/master/arsenal-lake-setup/README.md)

## [docker 버전](http://gitlab.msa.kt.com/datalake/datalake/tree/master/arsenal-lake-docker/README.md)