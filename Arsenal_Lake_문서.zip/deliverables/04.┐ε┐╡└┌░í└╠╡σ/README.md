# 운영자 가이드

## [개발 가이드](http://gitlab.msa.kt.com/datalake/datalake/blob/master/deliverables/04.%EC%9A%B4%EC%98%81%EC%9E%90%EA%B0%80%EC%9D%B4%EB%93%9C/%EA%B0%9C%EB%B0%9C%20%EA%B0%80%EC%9D%B4%EB%93%9C.md)

## [사용 가이드](http://gitlab.msa.kt.com/datalake/datalake/blob/master/deliverables/04.%EC%9A%B4%EC%98%81%EC%9E%90%EA%B0%80%EC%9D%B4%EB%93%9C/%EC%82%AC%EC%9A%A9%20%EA%B0%80%EC%9D%B4%EB%93%9C.md)

## [운영 가이드](http://gitlab.msa.kt.com/datalake/datalake/blob/master/deliverables/04.%EC%9A%B4%EC%98%81%EC%9E%90%EA%B0%80%EC%9D%B4%EB%93%9C/%EC%9A%B4%EC%98%81%20%EA%B0%80%EC%9D%B4%EB%93%9C.md)

## [연동 가이드](http://gitlab.msa.kt.com/datalake/datalake/blob/master/deliverables/04.%EC%9A%B4%EC%98%81%EC%9E%90%EA%B0%80%EC%9D%B4%EB%93%9C/%EC%97%B0%EB%8F%99%20%EA%B0%80%EC%9D%B4%EB%93%9C.md)