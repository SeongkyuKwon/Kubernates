# Spark Streaming 예제

#### 1. 개정이력

|    날짜    | 변경내용  | 작성자 | 비고 |
| :--------: | :-------: | :----: | :--: |
| 2019.04.08 | 최조 작성 | 김성구 |      |
|            |           |        |      |
|            |           |        |      |



#### 2. 목차

[TOC]

#### 3. Spark Streaming 예제

#### 3.1 개요

Spark Streaming 예제 코드를 python 코드로 작성하고 spark-submit 명령을 이용한 테스트 진행 과정 및 결과를 공유한다.

#### 3.2 목적

- spark-submit 명령을 사용하여 단독 실행 기능을 확인한다.

- python 파일 단위의 단독 실행 기능을 확인한다.

- Spark Streaming 예제 코드 작성 및 테스트 결과를 확인한다.

#### 3.3 예제 코드

- 언어 : Python

- 파일명 : streaming.py

  ```
  # -*- coding: utf-8 -*-
  #한글 주석 오류 방지
  
  from pyspark import SparkContext
  from pyspark.streaming import StreamingContext
  import sys
  
  #argv[1] : port 번호
  #argv[2] : Stream Data 처리 간격(초)
  
  #Spark Context 생성 : 2개의 쓰레드로 로컬을 실행
  sc = SparkContext("local[2]", "SparkStreamingTest")
  
  #Streaming Context 생성: 처리간격=argv[2]
  ssc = StreamingContext(sc, int(sys.argv[2]))
  
  #Socket 연결 및 Stream 생성
  lines = ssc.socketTextStream("localhost", int(sys.argv[1]))
  #입력 데이터에서 " "으로 단어 분리
  words = lines.flatMap(lambda line: line.split(" "))
  #words.pprint()
  #단어 카운트 및 출력
  pairs = words.map(lambda word: (word, 1))
  wordCounts = pairs.reduceByKey(lambda x, y: x + y)
  wordCounts.pprint()
  
  #생성된 Stream 시작
  ssc.start()
  #Stream 작업 종료시까지 대기
  ssc.awaitTermination()
  ```

#### 3.4 예제 코드 테스트 및 결과 확인

#### 3.4.1 Streaming 포트 오픈

- netcat 실행

- 포트번호 : 3333

  ```
  [root@localhost opt]# nc -lk 3333
  ```

#### 3.4.2 spark-submit 실행

- spark-submit 실행

- 포트번호 : 3333

- 실행 간격(초) : 10

  ```
  [root@localhost opt]# spark-submit ./streaming.py 3333 10
  ```

#### 3.4.3 Streaming Data 입력

- nc 실행 터미널에서 데이터 입력

  ```
  kt sk lg
  kt sk
  kt
  ```

#### 3.4.4 Streaming 결과 확인

- spark-submit 실행 터미널에서 결과 확인

- 실행 간격의 시간까지 입력된 데이터들의 워드 카운트 출력

- 입력된 데이터가 없을 경우 시간 출력

  ```
  ------------------------------------------
  Time: 2019-04-08 13:07:50
  -------------------------------------------
  (u'sk', 2)
  (u'lg', 1)
  (u'kt', 3)
  
  -------------------------------------------
  Time: 2019-04-08 13:08:00
  -------------------------------------------
  ```

#### 3.4.5 Streaming 종료

- spark-submit 종료

  ```
  [root@localhost opt]# ^Z
  [2]+  Stopped                 spark-submit ./streaming.py 3333 10
  ```

- netcat 종료

  ```
  [root@localhost opt]# ^Z
  [1]+  Stopped                 nc -lk 3333
  ```

  
